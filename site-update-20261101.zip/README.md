# Spyder Network — spider.ac

Static, responsive **coming-soon** website for Spyder Network. This repository deploys to **Cloudflare Pages** using GitHub Actions.

## Structure

```text
.github/workflows/unpack-site.yml     # Upload separately through GitHub UI
.github/workflows/deploy-pages.yml    # Upload separately through GitHub UI
public/index.html                     # Landing page
public/styles.css                     # Responsive styling and animations
public/app.js                         # RU/EN and Signal Red/Electric Blue toggles
public/favicon.svg                    # Brand favicon
public/apple-touch-icon.png           # iOS home-screen icon
public/manifest.webmanifest           # Web manifest
public/404.html                       # Custom 404
public/_headers                       # Browser security headers
public/robots.txt                     # Crawler instructions
README.md                             # This file
```

## First-time setup

1. Add `.github/workflows/unpack-site.yml` and `.github/workflows/deploy-pages.yml` individually through GitHub's **Add file → Create new file**, using the two standalone YAML files provided with the site package. **Do not upload the workflows inside the update ZIP.**
2. Cloudflare → **Workers & Pages** → **Create** → **Pages** → **Direct Upload**. Create project named exactly `spider-ac` with production branch `main`. If asked to upload something at creation time, upload the `public/` folder as the initial static assets; otherwise create the project first and let the workflow deploy.
3. Cloudflare → **My Profile / API Tokens**: create a token with **Account / Cloudflare Pages / Edit** permission, scoped to your Cloudflare account.
4. GitHub repo → **Settings → Secrets and variables → Actions → New repository secret**. Create `CLOUDFLARE_API_TOKEN` and `CLOUDFLARE_ACCOUNT_ID`.
5. Upload `site-update-20261101.zip` to the **root** of `main`, not to the `.github` folder. It includes `public/` and `README.md`. The **Unpack site update** workflow will extract it, commit the files, and delete the ZIP from the repository.
6. When unpack succeeds, **Deploy site to Cloudflare Pages** runs automatically via a `workflow_run` event. You can also run that workflow manually from Actions.
7. Cloudflare → your Pages project → **Custom domains → Set up a domain** → enter `spider.ac`. Your `spider.ac` root domain must be in the same Cloudflare account, with Cloudflare nameservers active. Cloudflare will create the corresponding DNS record. Optionally add `www.spider.ac` afterward.

**Important:** If GitHub Actions cannot push the unpacked files, verify **Settings → Actions → General → Workflow permissions** and branch protection. The unpack workflow requires `contents: write` to create the commit. The Deploy workflow uses read-only repository permissions.

## Updating the website

Prepare a ZIP named `site-update-YYYYMMDD.zip` containing repository-relative paths (`public/...`, optionally `README.md`) directly at its root. Upload to `main`. Do not wrap the files in an extra folder and do not include `.github/workflows` inside it. The archive is applied **incrementally**: absent files remain intact; included files are replaced. The unpack workflow rejects paths outside `public/` and `README.md`, symbolic links, unsafe path traversal, and unusually large archives.

If you edit `public/` directly in GitHub, the Deploy workflow also runs automatically. If you edit `README.md` only, the site does not need a redeployment.

## Development and launch notes

- No npm install or backend is required. To preview locally: `python3 -m http.server 8000 -d public` and open `http://localhost:8000/`.
- The page supports English and Russian, responsive layouts, reduced-motion preferences, and red/blue accent personalization.
- The landing page deliberately uses `<meta name="robots" content="noindex, nofollow">` while it is a placeholder. Remove or change this before public search indexing is desired.
- No real wallet connection, messages, transactions, email collection, or login are implemented here. This is an informational holding page only.
- Domain activation and the Cloudflare account setup require access to the owner's accounts and cannot be completed by merely uploading the code.
