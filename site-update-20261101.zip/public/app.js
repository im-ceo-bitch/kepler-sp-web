(() => {
  'use strict';
  const messages = {
    en: {
      navNetwork: 'Network', navEcosystem: 'Ecosystem', navVision: 'Vision', headerExplore: 'Explore',
      eyebrow: 'A NEW NETWORK IS FORMING', heroOne: 'The future', heroTwo: 'is connected.',
      heroDescription: 'One identity. Infinite connections. Wallet, messages, and the network itself — designed to feel like one experience.',
      discover: 'Discover Spyder', learnMore: 'Our vision', development: 'In development · More soon',
      sectionKicker: '01 / OUR ECOSYSTEM', ecosystemTitle: 'One connected world.',
      ecosystemDescription: 'Built as separate products. Designed to work together.',
      walletText: 'Your assets, your access. A wallet designed for a connected digital life.',
      networkText: 'A new approach to private, cryptographic communication.',
      chainText: 'The infrastructure layer for an evolving digital ecosystem.',
      inDevelopment: 'In development', visionKicker: "02 / WHAT'S NEXT", visionTitle: 'The network is just beginning.',
      visionText: "We're building something different. The first chapter of Spyder is on its way.",
      visionStatus: 'Development in progress', footer: 'Built for what comes next.'
    },
    ru: {
      navNetwork: 'Сеть', navEcosystem: 'Экосистема', navVision: 'Концепция', headerExplore: 'Узнать больше',
      eyebrow: 'РОЖДАЕТСЯ НОВАЯ СЕТЬ', heroOne: 'Будущее', heroTwo: 'уже на связи.',
      heroDescription: 'Одна идентичность. Бесконечные связи. Кошелёк, сообщения и сама сеть — как единое пространство.',
      discover: 'Открыть Spyder', learnMore: 'Наша концепция', development: 'В разработке · Скоро больше',
      sectionKicker: '01 / НАША ЭКОСИСТЕМА', ecosystemTitle: 'Один связанный мир.',
      ecosystemDescription: 'Отдельные продукты, созданные для совместной работы.',
      walletText: 'Ваши активы — ваш контроль. Кошелёк для новой цифровой жизни.',
      networkText: 'Новый подход к приватной криптографической коммуникации.',
      chainText: 'Инфраструктурная основа развивающейся цифровой экосистемы.',
      inDevelopment: 'В разработке', visionKicker: '02 / ЧТО ДАЛЬШЕ', visionTitle: 'Сеть только начинает формироваться.',
      visionText: 'Мы создаём нечто новое. Первая глава Spyder уже на пути.',
      visionStatus: 'Идёт разработка', footer: 'Создаём то, что будет дальше.'
    }
  };

  const langButton = document.getElementById('lang-toggle');
  const accentButton = document.getElementById('accent-toggle');
  const getSaved = (key) => { try { return localStorage.getItem(key); } catch { return null; } };
  const setSaved = (key, value) => { try { localStorage.setItem(key, value); } catch { /* Private browsing can deny storage. */ } };

  function applyLanguage(lang) {
    const chosen = Object.hasOwn(messages, lang) ? lang : 'en';
    document.documentElement.lang = chosen;
    document.querySelectorAll('[data-i18n]').forEach((el) => {
      const key = el.getAttribute('data-i18n');
      if (Object.hasOwn(messages[chosen], key)) el.textContent = messages[chosen][key];
    });
    langButton.textContent = chosen === 'en' ? 'RU' : 'EN';
    langButton.setAttribute('aria-label', chosen === 'en' ? 'Switch to Russian' : 'Switch to English');
    setSaved('spyder-language', chosen);
  }

  function applyAccent(accent) {
    const chosen = accent === 'blue' ? 'blue' : 'red';
    document.documentElement.dataset.accent = chosen;
    accentButton.setAttribute('aria-label', chosen === 'red' ? 'Switch to electric blue' : 'Switch to signal red');
    accentButton.title = chosen === 'red' ? 'Electric Blue' : 'Signal Red';
    setSaved('spyder-accent', chosen);
  }

  applyLanguage(getSaved('spyder-language') || 'en');
  applyAccent(getSaved('spyder-accent') || 'red');
  langButton.addEventListener('click', () => applyLanguage(document.documentElement.lang === 'en' ? 'ru' : 'en'));
  accentButton.addEventListener('click', () => applyAccent(document.documentElement.dataset.accent === 'red' ? 'blue' : 'red'));
  document.getElementById('copyright-year').textContent = String(new Date().getFullYear());
})();
